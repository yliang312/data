package main

import (
	"context"
	"dpiGo/dpiProto"
	"fmt"
	"net"

	"google.golang.org/grpc"
)

const (
	port = "41005"
)

type TestProto struct{}

func main() {

	//起服务
	lis, err := net.Listen("tcp", ":"+port)
	if err != nil {
		fmt.Printf("failed to listen: %v", err)
	}
	s := grpc.NewServer()
	dpiProto.RegisterTestProtoServer(s, &TestProto{})
	s.Serve(lis)

	fmt.Printf("grpc server in: %s", port)
}

//sayHello
func (t *TestProto) SayHello(ctx context.Context, request *dpiProto.HelloRequest) (response *dpiProto.HelloReply, err error) {
	response = &dpiProto.HelloReply{}
	response.Message = request.Name
	response.ValU32 = request.ValU32 + 1

	return response, err
}
